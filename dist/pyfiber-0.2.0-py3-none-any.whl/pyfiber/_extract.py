# BEHAVIORAL DATA


#==> return behavioral data as a dictionnary of timestamps (+ coordinates)


#==> alternative with csv (ttl like)


# FIBER DATA

#==> just the extraction with the specific nomenclature (can be put inside)