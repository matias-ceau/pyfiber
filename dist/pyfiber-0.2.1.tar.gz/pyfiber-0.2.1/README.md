# pyFiber

Object-oriented fiber photometry and behavioral data analysis toolkit.

## Installation

```bash
pip install pyfiber
```


